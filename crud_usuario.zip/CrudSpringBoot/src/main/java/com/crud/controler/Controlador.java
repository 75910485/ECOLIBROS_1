package com.crud.controler;
import com.crud.modelo.Usuario;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.crud.interfaceService.IusuarioService;

@Controller
@RequestMapping
public class Controlador {
	
	@Autowired
	private IusuarioService service;
	
	@GetMapping("/listar")
	public String listar (Model model) {
		List<Usuario>usuarios=service.listar();
		model.addAttribute("usuarios", usuarios);
		return "index";
	}
	
	@GetMapping("/new")
	public String agregar(Model model) {
	    model.addAttribute("usuario", new Usuario()); // Aquí estamos agregando un nuevo objeto Usuario al modelo
	    return "Form";
	}

	@PostMapping("/save")
	public String save(@Validated Usuario p, Model model) {
		service.save(p);
		return "redirect:/listar";
	}
}
