package com.crud.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.interfaceService.IusuarioService;
import com.crud.interfaces.IUsuario;
import com.crud.modelo.Usuario;

@Service
public class UsuarioService implements IusuarioService{

	@Autowired
	private IUsuario data;
	
	@Override
	public List<Usuario> listar() {
		return (List<Usuario>)data.findAll();
	}

	@Override
	public Optional<Usuario> listarId(int id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public int save(Usuario p) {
	    int res = 0;
	    Optional<Usuario> existingUser = data.findById(p.getId());
	    if (existingUser.isPresent()) {
	    } else {
	        Usuario usuario = data.save(p);
	        if (usuario != null) {
	            res = 1;
	        }
	    }
	    return res;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

}
